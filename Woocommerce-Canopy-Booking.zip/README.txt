=== WCB ===
Contributors: Jesús Magallón <jesus@yosoydev.net>
Tags: woocommerce, tours, plugins, canopy
Requires at least: 3.0.1
Tested up to: 4.9.8
Stable tag: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin allows adding sales support for tours in woocommerce adding fields for children, adults, date of reservation and bus stops.

== Installation ==

This section describes how to install the plugin and get it working.


1. Upload `Woocommerce-Canopy-Booking.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Enjoy :)
